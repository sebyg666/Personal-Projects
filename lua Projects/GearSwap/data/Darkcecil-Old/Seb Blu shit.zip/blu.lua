-------------------------------------------------------------------------------------------------------------------
-- Setup functions for this job.  Generally should not be modified.
-------------------------------------------------------------------------------------------------------------------
include('Organizer-lib.lua')
-- include('Haste2_parsing.lua')
-- res = require('resources')
-- spells = res.spells:type('BlueMagic')


-- Initialization function for this job file.
function get_sets()
    mote_include_version = 2

    -- Load and initialize the include file.
    include('Mote-Include.lua')
	include('Mote-SelfCommands_with_color.lua')

end

-- Setup vars that are user-independent.  state.Buff vars initialized here will automatically be tracked.
function job_setup()
    state.Buff['Burst Affinity'] = buffactive['Burst Affinity'] or false
    state.Buff['Chain Affinity'] = buffactive['Chain Affinity'] or false
	state.Buff['Mighty Guard'] =  buffactive['Mighty Guard'] or false
    state.Buff.Convergence = buffactive.Convergence or false
    state.Buff.Diffusion = buffactive.Diffusion or false
    state.Buff.Efflux = buffactive.Efflux or false
	state.Buff.doom = buffactive.doom or false
	state.Buff["Reive Mark"] = buffactive["Reive Mark"] or false
    state.Buff['Unbridled Learning'] = buffactive['Unbridled Learning'] or false
	
	state.Buff['Geo-Haste'] = false
	state.Buff['Haste'] = false
	state.Buff['Haste II'] = false
	state.Buff['Marches'] = 0
	info['Hsamba'] = false
	DW_needed = 0

    blue_magic_maps = {}
    
    -- Mappings for gear sets to use for various blue magic spells.
    -- While Str isn't listed for each, it's generally assumed as being at least
    -- moderately signficant, even for spells with other mods.
    
    -- Physical Spells --
    
    -- Physical spells with no particular (or known) stat mods
    blue_magic_maps.Physical = S{
        'Bilgestorm','Saurian Slide'
    }

    -- Spells with heavy accuracy penalties, that need to prioritize accuracy first.
    blue_magic_maps.PhysicalAcc = S{
        'Heavy Strike',
    }

    -- Physical spells with Str stat mod
    blue_magic_maps.PhysicalStr = S{
        'Battle Dance','Bloodrake','Death Scissors','Dimensional Death','Empty Thrash',
		'Heavy Strike','Quadrastrike','Uppercut','Tourbillion','Vertical Cleave',
		
		'Whirl of Rage','Glutinous Dart','Sweeping Gouge','Sinker Drill'
    }
        
    -- Physical spells with Dex stat mod
    blue_magic_maps.PhysicalDex = S{
        'Amorphic Spikes','Asuran Claws','Barbed Crescent','Claw Cyclone','Disseverment',
        'Foot Kick','Frenetic Rip','Goblin Rush','Hysteric Barrage','Paralyzing Triad',
        'Seedspray','Sickle Slash','Smite of Rage','Terror Touch','Thrashing Assault',
        'Vanity Dive'
    }
        
    -- Physical spells with Vit stat mod
    blue_magic_maps.PhysicalVit = S{
        'Body Slam','Cannonball','Delta Thrust','Glutinous Dart','Grand Slam',
        'Power Attack','Quad. Continuum','Sprout Smack','Sub-zero Smash'
    }
        
    -- Physical spells with Agi stat mod
    blue_magic_maps.PhysicalAgi = S{
        'Benthic Typhoon','Feather Storm','Helldive','Hydro Shot','Jet Stream',
        'Pinecone Bomb','Spiral Spin','Wild Oats'
    }

    -- Physical spells with Int stat mod
    blue_magic_maps.PhysicalInt = S{
        'Mandibular Bite','Queasyshroom'
    }

    -- Physical spells with Mnd stat mod
    blue_magic_maps.PhysicalMnd = S{
        'Ram Charge','Screwdriver','Tourbillion'
    }

    -- Physical spells with Chr stat mod
    blue_magic_maps.PhysicalChr = S{
        'Bludgeon'
    }

    -- Physical spells with HP stat mod
    blue_magic_maps.PhysicalHP = S{
        'Final Sting'
    }

    -- Magical Spells --

    -- Magical spells with the typical Int mod
    blue_magic_maps.Magical = S{
        'Blastbomb','Blazing Bound','Bomb Toss','Cursed Sphere','Dark Orb','Death Ray',
        'Diffusion Ray','Droning Whirlwind','Embalming Earth','Firespit','Foul Waters',
        'Ice Break','Leafstorm','Maelstrom','Rail Cannon','Regurgitation','Rending Deluge',
        'Retinal Glare','Subduction','Tem. Upheaval','Water Bomb','Tenebral Crush','Palling Salvo',
		'Entomb','Silent Storm','Anvil Lightning','Scouring Spate','Spectral Floe','Blinding Fulgor',
		'Searing Tempest','Atramentous Libations','Nectarous Deluge','Molting Plumage'
    }

    -- Magical spells with a primary Mnd mod
    blue_magic_maps.MagicalMnd = S{
        'Acrid Stream','Evryone. Grudge','Magic Hammer','Mind Blast'
    }

    -- Magical spells with a primary Chr mod
    blue_magic_maps.MagicalChr = S{
        'Eyes On Me','Mysterious Light'
    }

    -- Magical spells with a Vit stat mod (on top of Int)
    blue_magic_maps.MagicalVit = S{
        'Thermal Pulse'
    }

    -- Magical spells with a Dex stat mod (on top of Int)
    blue_magic_maps.MagicalDex = S{
        'Charged Whisker','Gates of Hades'
    }
            
    -- Magical spells (generally debuffs) that we want to focus on magic accuracy over damage.
    -- Add Int for damage where available, though.
    blue_magic_maps.MagicAccuracy = S{
        '1000 Needles','Absolute Terror','Actinic Burst','Auroral Drape','Awful Eye',
        'Blank Gaze','Blistering Roar','Blood Drain','Blood Saber','Chaotic Eye',
        'Cimicine Discharge','Cold Wave','Corrosive Ooze','Demoralizing Roar','Digest',
        'Dream Flower','Enervation','Feather Tickle','Filamented Hold','Frightful Roar',
        'Geist Wall','Hecatomb Wave','Infrasonics','Jettatura','Light of Penance',
        'Lowing','Mind Blast','Mortal Ray','MP Drainkiss','Osmosis','Reaving Wind',
        'Sandspin','Sandspray','Sheep Song','Soporific','Sound Blast','Stinking Gas',
        'Sub-zero Smash','Venom Shell','Voracious Trunk','Yawn'
    }
        
    -- Breath-based spells
    blue_magic_maps.Breath = S{
        'Bad Breath','Flying Hip Press','Frost Breath','Heat Breath',
        'Hecatomb Wave','Magnetite Cloud','Poison Breath','Radiant Breath','Self-Destruct',
        'Thunder Breath','Vapor Spray','Wind Breath'
    }

    -- Stun spells
    blue_magic_maps.Stun = S{
        'Blitzstrahl','Frypan','Head Butt','Sudden Lunge','Tail slap','Temporal Shift',
        'Thunderbolt','Whirl of Rage'
    }
        
    -- Healing spells
    blue_magic_maps.Healing = S{
        'Healing Breeze','Magic Fruit','Plenilune Embrace','Pollen','Restoral','White Wind',
        'Wild Carrot'
    }
    
    -- Buffs that depend on blue magic skill
    blue_magic_maps.SkillBasedBuff = S{
        'Barrier Tusk','Diamondhide','Magic Barrier','Metallic Body','Plasma Charge',
        'Pyric Bulwark','Reactor Cool',
    }

    -- Other general buffs
    blue_magic_maps.Buff = S{
        'Amplification','Animating Wail','Battery Charge','Carcharian Verve','Cocoon',
        'Erratic Flutter','Exuviation','Fantod','Feather Barrier','Harden Shell',
        'Memento Mori','Nat. Meditation','Occultation','Orcish Counterstance','Refueling',
        'Regeneration','Saline Coat','Triumphant Roar','Warm-Up','Winds of Promyvion',
        'Zephyr Mantle'
    }
    
    
    -- Spells that require Unbridled Learning to cast.
    unbridled_spells = S{
        'Absolute Terror','Bilgestorm','Blistering Roar','Bloodrake','Carcharian Verve',
        'Crashing Thunder','Droning Whirlwind','Gates of Hades','Harden Shell','Polar Roar',
        'Pyric Bulwark','Thunderbolt','Tourbillion','Uproot'
    }
end

-------------------------------------------------------------------------------------------------------------------
-- User setup functions for this job.  Recommend that these be overridden in a sidecar file.
-------------------------------------------------------------------------------------------------------------------

-- Setup vars that are user-dependent.  Can override this function in a sidecar file.
function user_setup()
    state.OffenseMode:options('Normal', 'Ilvl~118', 'Ilvl~122', 'Ilvl~124+')
    state.HybridMode:options('Normal', 'Evasion')
    state.WeaponskillMode:options('Normal', 'Ilvl~118', 'Ilvl~122', 'Ilvl~124+')
    state.CastingMode:options('Normal', 'Resistant')
    state.IdleMode:options('Normal', 'PDT')
	state.PhysicalDefenseMode:options('PDT')
	options.MagicalDefenseModes = {'MDT'}
	
	state.CP  				= M(false, 'CP')
	state.Learning  		= M(false, 'Learning')
	
	state.PhysicalDefense   = M(false, 'PhysicalDefense')
	state.MagicalDefense    = M(false, 'MagicalDefense')
	
	send_command('bind !f12 gs c cycle IdleMode')
	send_command('bind ^f12 gs c cycle CastingMode')
	send_command('bind ^F11 gs c cycle CP')
	send_command('bind !F11 gs c cycle Learning')
	
	Ring_lock = S{"Warp Ring", "Resolution Ring", "Emperor Band", "Capacity Ring", "Echad Ring", "Trizek Ring", "Facility Ring", "Caliber Ring", "Dim. Ring (Dem)"}
	Ear_lock = S{"Reraise Earring"}
	Two_Handed = S{'Hoe', 'Pitchfork +1', 'Ark Tachi', 'Fire Staff'}
	Max_Bards = S{'Kittensgomew', 'Darklabyrinth'}
	
	-- if areas.Cities:contains(world.area) and world.area ~= "Mhaura" and world.area ~= "Selbina" and world.area ~= "Norg" then
		-- send_command('wait 2; input //gs lo; wait 3; input //gs c update user; input //gs validate')
	-- end
	
	info.haste = 'None'
	Notification_color = 200
	text_color = 160
	warning_text = 167
	
	include('Haste2_parsing.lua')
	res = require('resources')
	spells = res.spells:type('BlueMagic')
	
	send_command('text textbox create "this box exists"')
	send_command('text textbox size 10')
	send_command('text textbox pos 1085 610')
	
	old_text = ''
	
    select_default_macro_book()
	update_combat_form()
	determine_haste_group()
	
	windower.raw_register_event('prerender',update_text)
	windower.raw_register_event('logout',reset_text)
	send_command('gs c update')
end


-- Called when this job file is unloaded (eg: job change)
function user_unload()
	send_command('text textbox delete')
end

function reset_text()
	send_command('text textbox delete')
end

-- Set up gear sets.
function init_gear_sets()
    
	
end

-------------------------------------------------------------------------------------------------------------------
-- Job-specific hooks for standard casting events.
-------------------------------------------------------------------------------------------------------------------

-- Set eventArgs.handled to true if we don't want any automatic gear equipping to be done.
-- Set eventArgs.useMidcastGear to true if we want midcast gear equipped on precast.
function job_precast(spell, action, spellMap, eventArgs)
    if unbridled_spells:contains(spell.english) and not state.Buff['Unbridled Learning'] then
        eventArgs.cancel = true
        windower.send_command('@input /ja "Unbridled Learning" <me>; wait 1.5; input /ma "'..spell.name..'" '..spell.target.name)
    end
	if spell.type == 'WeaponSkill' then
		-- if spell.target.distance > 5 then
			-- eventArgs.cancel = true
			-- add_to_chat(123,('[Abort WS: '):color(warning_text) .. ('\"' .. spell.name .. '\"'):color(Notification_color) .. (' -> Target is too far.'):color(text_color) .. (']'):color(warning_text))
			-- return
		-- end
		-- Stop Gear Switching if in any Defence Sets
		--if state.DefenseMode.current ~= 'None' then eventArgs.handled = true end
		-- Abort WS if TP < 1000
		if player.tp < 999 then
			add_to_chat(123,('[Abort WS: '):color(warning_text) .. ('\"' .. spell.name .. '\"'):color(Notification_color) .. (' -> TP: '..player.tp..' / 3000'):color(text_color) .. (']'):color(warning_text))
			eventArgs.cancel = true
			return
		end
	end
end

-- Run after the default midcast() is done.
-- eventArgs is the same one used in job_midcast, in case information needs to be persisted.
function job_post_midcast(spell, action, spellMap, eventArgs)
    -- Add enhancement gear for Chain Affinity, etc.
    if spell.skill == 'Blue Magic' then
        for buff,active in pairs(state.Buff) do
            if active and sets.buff[buff] then
                equip(sets.buff[buff])
            end
        end
        if spellMap == 'Healing' and spell.target.type == 'SELF' and sets.self_healing then
            equip(sets.self_healing)
        end
    end
end

-- Set eventArgs.handled to true if we don't want any automatic gear equipping to be done.
function job_aftercast(spell, action, spellMap, eventArgs)
   
end

-------------------------------------------------------------------------------------------------------------------
-- Job-specific hooks for non-casting events.
-------------------------------------------------------------------------------------------------------------------

-- Called when a player gains or loses a buff.
-- buff == buff gained or lost
-- gain == true if the buff was gained, false if it was lost.
function job_buff_change(buff, gain, buff_info)
	--add_to_chat(200, buff .. '  ' .. tostring(gain) )
	if buff == 'Haste' and gain == true then
		if buff_info.id == 580 then 
			state.Buff['Geo-Haste'] = true 
		elseif buff_info.id == 33 then 
			state.Buff['Haste'] = true
		end
	elseif buff == 'Haste' and gain == false then
		if buff_info.id == 580 then 
			state.Buff['Geo-Haste'] = false 
		elseif buff_info.id == 33 then 
			state.Buff['Haste'] = false
			state.Buff['Haste II'] = false
		end
	end
	if state.Buff[buff] ~= nil and buff ~= 'Haste' then
		state.Buff[buff] = gain
	end

	--Change_Marches()
    handle_equipping_gear(player.status)
end

-- Called when the player's status changes.
function job_state_change(field, new_value, old_value)

	if state.OffenseMode.value == 'Normal' then
		state.WeaponskillMode:set('Normal')
	elseif state.OffenseMode.value == 'Ilvl~118' then
		state.WeaponskillMode:set('Ilvl~118')
	elseif state.OffenseMode.value == 'Ilvl~122' then
		state.WeaponskillMode:set('Ilvl~122')
	elseif state.OffenseMode.value == 'Ilvl~124+' then
		state.WeaponskillMode:set('Ilvl~124+')
	end
	
	if field == "PhysicalDefense" then
		if state.PhysicalDefense.value == true then
			state.DefenseMode.current = 'Physical'
			state.DefenseMode:set('Physical')
			state.MagicalDefense = M(false)
		end
	elseif field == "MagicalDefense" then
		if state.MagicalDefense.value == true then
			state.DefenseMode.current = 'Magical'
			state.DefenseMode:set('Magical')
			state.PhysicalDefense = M(false)
		end
	end
	if field == "MagicalDefense" or field == "PhysicalDefense" then
		if state.PhysicalDefense.value == false and state.MagicalDefense.value == false then
			state.DefenseMode.current = 'None'
			state.DefenseMode:set('None')
		end
    end
end

function job_status_change(new_status, old_status)
	if new_status == 'Idle' then
		info['Hsamba'] = false
    end
	handle_equipping_gear(player.status)
end

-------------------------------------------------------------------------------------------------------------------
-- User code that supplements standard library decisions.
-------------------------------------------------------------------------------------------------------------------

-- Called any time we attempt to handle automatic gear equips (ie: engaged or idle gear).
function job_handle_equipping_gear(playerStatus, eventArgs)
    update_combat_form()
	--Change_Marches()
	determine_haste_group()
end

-- Custom spell mapping.
-- Return custom spellMap value that can override the default spell mapping.
-- Don't return anything to allow default spell mapping to be used.
function job_get_spell_map(spell, default_spell_map)
    if spell.skill == 'Blue Magic' then
        for category,spell_list in pairs(blue_magic_maps) do
            if spell_list:contains(spell.english) then
                return category
            end
        end
    end
end

-- Modify the default idle set after it was constructed.
function customize_idle_set(idleSet)
    if state.Buff.doom then
        idleSet = set_combine(idleSet, sets.buff.Doom)
		add_to_chat(200,('__\\||//__***** '):color(Notification_color) .. (' Doomed '):color(warning_text) .. ('*****__\\||//__'):color(Notification_color) )
    end
	if state.Buff["Reive Mark"] then
		idleSet = set_combine(idleSet, sets.buff.Reive)
	end
	
	---------------------------------
	if Ring_lock:contains(player.equipment.ring1) and areas.Cities:contains(world.area) then
		enable('ring1')
		add_to_chat(200,('[In Town: '):color(Notification_color) .. ('-> Removing \"'..player.equipment.ring1 .. '\"'):color(text_color) .. (']'):color(Notification_color) )
	elseif Ring_lock:contains(player.equipment.ring1) then
		disable('ring1')
	end
	if Ring_lock:contains(player.equipment.ring2) and areas.Cities:contains(world.area) then
		enable('ring2')
		add_to_chat(200,('[In Town: '):color(Notification_color) .. ('-> Removing \"'..player.equipment.ring2 .. '\"'):color(text_color) .. (']'):color(Notification_color) )
	elseif Ring_lock:contains(player.equipment.ring2) then
		disable('ring2')
	end
	---------------------------------
	if Ear_lock:contains(player.equipment.ear1) and areas.Cities:contains(world.area) then
		enable('Ear1')
		add_to_chat(200,('[In Town: '):color(Notification_color) .. ('-> Removing \"'..player.equipment.ear1 .. '\"'):color(text_color) .. (']'):color(Notification_color) )
	elseif Ear_lock:contains(player.equipment.ear1) then
		disable('Ear1')
	end
	if Ear_lock:contains(player.equipment.ear2) and areas.Cities:contains(world.area) then
		enable('Ear2')
		add_to_chat(200,('[In Town: '):color(Notification_color) .. ('-> Removing \"'..player.equipment.ear2 .. '\"'):color(text_color) .. (']'):color(Notification_color) )
	elseif Ear_lock:contains(player.equipment.ear2) then
		disable('Ear2')
	end
	
	if state.CP.value == true then
		idleSet = set_combine(idleSet, sets.CP)
	end
	if state.Learning.value == true then
		idleSet = set_combine(idleSet, sets.Learning)
	end
	if player.mpp < 51 then
        idleSet = set_combine(idleSet, sets.latent_refresh)
    end
    return idleSet
end

-- Modify the default melee set after it was constructed.
function customize_melee_set(meleeSet)
	if Ring_lock:contains(player.equipment.ring1) then
		enable('ring1')
		add_to_chat(200,('[Mob Engaged: '):color(warning_text) .. ('-> Removing \"'..player.equipment.ring1 .. '\"'):color(text_color) .. (']'):color(warning_text) )
	end
	if Ring_lock:contains(player.equipment.ring2) then
		enable('ring2')
		add_to_chat(200,('[Mob Engaged: '):color(warning_text) .. ('-> Removing \"'..player.equipment.ring2 .. '\"'):color(text_color) .. (']'):color(warning_text) )
	end
	--------------------------------------
	if Ear_lock:contains(player.equipment.ear1) then
		enable('ear1')
		add_to_chat(200,('[Mob Engaged: '):color(warning_text) .. ('-> Removing \"'..player.equipment.ear1 .. '\"'):color(text_color) .. (']'):color(warning_text) )
	end
	if Ear_lock:contains(player.equipment.ear2) then
		enable('ear2')
		add_to_chat(200,('[Mob Engaged: '):color(warning_text) .. ('-> Removing \"'..player.equipment.ear2 .. '\"'):color(text_color) .. (']'):color(warning_text) )
	end
	---------------------------------------
    if state.Buff.doom then
        meleeSet = set_combine(meleeSet, sets.buff.Doom)
		add_to_chat(200,('__\\||//__***** '):color(Notification_color) .. (' Doomed '):color(warning_text) .. ('*****__\\||//__'):color(Notification_color) )
    end
	if state.Buff["Reive Mark"] then
		meleeSet = set_combine(meleeSet, sets.buff.Reive)
	end
	if state.CP.value == true then
		meleeSet = set_combine(meleeSet, sets.CP)
	end
	if state.Learning.value == true then
		meleeSet = set_combine(meleeSet, sets.Learning)
	end
    return meleeSet
end

-- Called by the 'update' self-command, for common needs.
-- Set eventArgs.handled to true if we don't want automatic equipping of gear.
function job_update(cmdParams, eventArgs)
	--Change_Marches()
	state.Buff['Geo-Haste'] = false
	state.Buff['Haste'] = false
	if player.buffs then	
		for index, buff in pairs(player.buffs) do
			if buff == 580 then 
				state.Buff['Geo-Haste'] = true
			elseif buff == 33 then
				state.Buff['Haste'] = true 
			end
		end
	end
	handle_equipping_gear(player.status)
end


-------------------------------------------------------------------------------------------------------------------
-- Utility functions specific to this job.
-------------------------------------------------------------------------------------------------------------------

function update_combat_form()
    -- Check for H2H or single-wielding
	if player.equipment.sub ~= 'empty' then 
		local sub_weapon = res.items:with('en', player.equipment.sub)
		if sub_weapon ~= nil then
			sub_weapon = sub_weapon.category
			--add_to_chat(122, sub_weapon)
			if sub_weapon == "Armor" then
				state.CombatForm:reset()
			else
				state.CombatForm:set('DW')
			end
		end
	else
		state.CombatForm:reset()
	end
end

-- Function to display the current relevant user state when doing an update.
-- Return true if display was handled, and you don't want the default info shown.
function display_current_job_state(eventArgs)
	
    local msg = ('   [Melee'):color(Notification_color)
    
    if state.CombatForm.has_value then
        msg = msg .. (' (' .. state.CombatForm.value .. ')'):color(text_color)
    end
    
	if #classes.CustomMeleeGroups > 0 then
        for i = 1,#classes.CustomMeleeGroups do
			if classes.CustomMeleeGroups[i] ~= 'None' then
				if i == 1 then
					msg = msg .. (' ('):color(Notification_color)
				end
				msg = msg .. (classes.CustomMeleeGroups[i]):color(Notification_color)
				if i < #classes.CustomMeleeGroups then
					msg = msg .. (' + '):color(Notification_color)
				end
				if i == #classes.CustomMeleeGroups then
					msg = msg .. (')'):color(Notification_color)
				end
			end
        end
    end
	
    msg = msg .. (': '):color(Notification_color)
    
   if state.DefenseMode.value == 'None' then
		msg = msg .. (state.OffenseMode.value):color(text_color)
	else
		msg = msg ..('LOCKED: ' ):color(warning_text) .. (state.OffenseMode.value):color(text_color)
	end
	
    if state.DefenseMode.value == 'None' then
		msg = msg .. ('] [WS: '):color(Notification_color) .. (state.WeaponskillMode.value):color(text_color) .. ('] '):color(Notification_color)
	else
		msg = msg .. ('] [WS: '):color(Notification_color) .. ('LOCKED: ' ):color(warning_text) .. (state.WeaponskillMode.value):color(text_color) .. ('] '):color(Notification_color)
	end
	
    msg = msg .. (' [Casting: '):color(Notification_color) .. (state.CastingMode.value):color(text_color) .. ('] '):color(Notification_color)
	
	msg = msg .. (' [Idle: '):color(Notification_color) .. (state.IdleMode.value):color(text_color) .. ('] '):color(Notification_color)
	
	if state.Kiting.value == true or state.CP.value == true or state.Learning.value == true then
        msg = msg .. '\n'
    end
	
    if state.Kiting.value == true then
        msg = msg .. ('[Kiting'):color(Notification_color) .. ('] '):color(Notification_color)
    end
	
	if state.CP.value == true then
        msg = msg .. ('[CP Cape'):color(Notification_color) .. ('] '):color(Notification_color)
    end
	
	if state.Learning.value == true then
        msg = msg .. ('[Learning'):color(Notification_color) .. ('] '):color(Notification_color)
    end

    if state.PCTargetMode.value ~= 'default' then
        msg = msg .. ('[Target PC: '):color(Notification_color)..state.PCTargetMode.value .. ('] '):color(Notification_color)
    end

    if state.SelectNPCTargets.value == true then
        msg = msg .. ('[Target NPCs'):color(Notification_color).. ('] '):color(Notification_color) .. ('] '):color(Notification_color)
    end
	
	msg = msg ..(' \n ')
	
	if info.haste ~= 'None' then
		msg = msg .. ('[\"' .. info.haste..'\"'):color(Notification_color) .. (' set @: '..Total_haste..'/1024 || DW: ' .. DW_needed):color(text_color) .. (']'):color(Notification_color)
	end
	
	if state.DefenseMode.value ~= 'None' then
        msg = msg  .. ('\n ')..('['):color(warning_text) .. ('Defense: '):color(warning_text) .. (state.DefenseMode.value .. ' (' .. state[state.DefenseMode.value .. 'DefenseMode'].value .. ')'):color(text_color)..('] '):color(warning_text)
    end
	
	add_to_chat(122, msg)
	eventArgs.handled = true
end

function update_text()

	local msg = '[Melee'
	
    if state.CombatForm.has_value then
        msg = msg .. ' (' .. state.CombatForm.value .. ')'
    end
    
	if #classes.CustomMeleeGroups > 0 then
        for i = 1,#classes.CustomMeleeGroups do
			if classes.CustomMeleeGroups[i] ~= 'None' then
				if i == 1 then
					msg = msg .. ' ('
				end
				msg = msg .. classes.CustomMeleeGroups[i]
				if i < #classes.CustomMeleeGroups then
					msg = msg .. ' + '
				end
				if i == #classes.CustomMeleeGroups then
					msg = msg .. ')'
				end
			end
        end
    end
	
    msg = msg .. ': '
    
   if state.DefenseMode.value == 'None' then
		msg = msg .. state.OffenseMode.value .. '] '
	else
		msg = msg ..'LOCKED: ' .. state.OffenseMode.value .. '] '
	end
	
    msg = msg .. '\n[Casting: ' .. state.CastingMode.value .. '] '
	
	msg = msg .. '\n[Idle: ' .. state.IdleMode.value .. ']'
	
	if state.Kiting.value == true or state.CP.value == true or state.Learning.value == true then
        msg = msg .. '\n'
    end
	
    if state.Kiting.value == true then
        msg = msg .. '[Kiting] '
    end
	
	if state.CP.value == true then
        msg = msg .. '[CP Cape] '
    end
	
	if state.Learning.value == true then
        msg = msg .. '[Learning] '
    end
	
	if info.haste ~= 'None' then
		msg = msg .. '\n[Haste: '..Total_haste..'/1024 || DW needed: ' .. DW_needed .. ']'
	end
	
	if state.DefenseMode.value ~= 'None' then
        msg = msg  .. '\n[' .. 'Defense: ' .. state.DefenseMode.value .. ' (' .. state[state.DefenseMode.value .. 'DefenseMode'].value .. ')] '
    end
	
	if msg ~= old_text then
		send_command('text textbox text ' .. msg)
		old_text = msg
	end
		
end
-------------------------------------------------------------------------------------------------------------------
-- Utility functions specific to this job.
-------------------------------------------------------------------------------------------------------------------

function determine_haste_group()
	
	-- HASTE INFO
    -------------------------------------------------------------------------------------------------
	-- Haste Samba = 5% 			51/1024
	
	-- haste = 14.7%    			150/1024				-- haste II = 30%    			307/1024
	
	-- Advancing March = 6.3%   	64/1024					-- Victory March = 9.4%   		96/1024
	-- Advancing March +1 = 7.9%   	80/1024                 -- Victory March +1 = 11%		112/1024
	-- Advancing March +2 = 9.4%   	96/1024                 -- Victory March +2 = 12.5%     128/1024
	-- Advancing March +3 = 11%    	112/1024                -- Victory March +3 = 14.1%     144/1024
	-- Advancing March +4 = 12.6	128/1024                -- Victory March +4 = 15.7%		160/1024
	-- Advancing March +5 = 14.1	144/1024                -- Victory March +5 = 17.2%		176/1024

	-------------------------------------------------------------------------------------------------
	-- magic haste cap = 43.8% 		448/1024
	-- Equipment haste cap = 25%	256/1024
	-- Job Ability haste cap = 25%	256/1024
	-- Ninja base Dual Weild = 35%	358/1024
	-- Total cap = 80%				820/1024	
	
	-- delay calc
	-- (delay1 + delay2) x (1-DW%) x (1024 - haste)/1024 >= (delay1 + delay2) x 0.2 
	-- total weapon delay x dual wiled x haste >= (has to be higher or equal to 80% of total delay)
	-- DW_needed = math.floor((((Total_Weapon_Delay * 0.2) / Total_Weapon_Delay / ((1024 - Total_haste) / 1024 ) -1) * -1 * 100) - Ninja_DW)
	
	
    info.haste = 'None'
	-- state.Buff['Geo-Haste']
	-- Magic Haste
	local M_Haste = 0
	if buffactive.embrava then 
		M_Haste = M_Haste + 205 
		--add_to_chat(122, 'Total Haste = '.. M_Haste .. ( ' Embrava '))
	end
	if buffactive['Mighty Guard'] then 
		M_Haste = M_Haste + 150 
		--add_to_chat(122, 'Total Haste = '.. M_Haste .. ( ' Mighty Guard '))
	end
	if state.Buff['Geo-Haste'] then 
		M_Haste = M_Haste + 358
		--add_to_chat(122, 'Total Haste = '.. M_Haste .. ( ' Geo '))
	end
	if state.Buff['Haste'] and not state.Buff['Haste II'] then 
		M_Haste = M_Haste + 150 
		--add_to_chat(122, 'Total Haste = '.. M_Haste .. ( ' Haste 1 '))
	end
	if state.Buff['Haste'] and state.Buff['Haste II'] then 
		M_Haste = M_Haste + 307 
		--add_to_chat(122, 'Total Haste = '.. M_Haste .. ( ' Haste 2 '))
	end
	
	if buffactive.march == 1 and state.Buff['Marches'] == 0 then 
		M_Haste = M_Haste + 96
		--add_to_chat(122, 'Total Haste = '.. M_Haste .. ( ' 1 March '))
	elseif buffactive.march == 1 and state.Buff['Marches'] ~= 0 then 
		M_Haste = M_Haste + state.Buff['Marches'] 
		--add_to_chat(122, 'Total Haste = '.. M_Haste .. ( ' 2 March '))
	end
	if buffactive.march == 2 and state.Buff['Marches'] == 0 then 
		M_Haste = M_Haste + 160
		--add_to_chat(122, 'Total Haste = '.. M_Haste .. ( ' 2 March '))
	elseif buffactive.march == 2 and state.Buff['Marches'] ~= 0 then 
		M_Haste = M_Haste + state.Buff['Marches'] 
		--add_to_chat(122, 'Total Haste = '.. M_Haste .. ( ' 2 March '))
	end
	if buffactive['Slow'] then 
		M_Haste = M_Haste - 150 
		--add_to_chat(122, 'Total Haste = '.. M_Haste .. ( ' Slow '))
	end
	if buffactive['Elegy'] then 
		M_Haste = M_Haste - 256 
		--add_to_chat(122, 'Total Haste = '.. M_Haste .. ( ' Elegy '))
	end
	
	-- magic haste cap
	if M_Haste > 448 then M_Haste = 448 end
	
	-- JA haste
	local JA_Haste = 0
	if buffactive['haste samba'] or info['Hsamba'] then JA_Haste = JA_Haste + 51 end
	
	--add_to_chat(122, 'samba: '..tostring(info['Hsamba']))
	
	
	--JA haste cap
	if JA_Haste > 256 then JA_Haste = 256 end
	
	-- gear haste
	local Gear_Haste = 256
	
	-- Calcs
	-- local Total_haste = 0
	Total_haste = M_Haste + JA_Haste + Gear_Haste
	if Total_haste > 820 then Total_haste = 820 end
	
	local Main = ""
	local Sub = ""
	if player.equipment.main ~= "empty" then
		Main = res.items:with('en', player.equipment.main)
	end
	if player.equipment.sub ~= "empty" then
		Sub = res.items:with('en', player.equipment.sub)
	end
	if Main ~= "" and Main ~= nil and Sub ~= "" and Sub ~= nil then
		Total_Weapon_Delay = Main.delay + Sub.delay
	else
		Total_Weapon_Delay = 0
	end
	--add_to_chat(122, 'Total_Weapon_Delay: '..tostring(Total_Weapon_Delay))
	--local Job_DW = 0
	Job_DW = determine_DW()
	--Job_DW = 25
	--add_to_chat(122, '[job dw: ' .. Job_DW .. ']')
	DW_needed = math.floor((((Total_Weapon_Delay * 0.2) / Total_Weapon_Delay / ((1024 - Total_haste) / 1024 ) -1) * -1 * 100) - Job_DW)
	
	classes.CustomMeleeGroups:clear()
	-- Choose gearset based on DW needed
	if DW_needed <= 5 then
		classes.CustomMeleeGroups:append('DW: 5-0')
		info.haste = 'DW: 5-0'
	elseif DW_needed > 5 and DW_needed < 12 then
		classes.CustomMeleeGroups:append('DW: 6-11')
		info.haste = 'DW: 6-11'
	elseif DW_needed > 11 and DW_needed < 22 then
		classes.CustomMeleeGroups:append('DW: 12-21')
		info.haste = 'DW: 12-21'
	elseif DW_needed > 21 and DW_needed < 37 then
		classes.CustomMeleeGroups:append('DW: 22-36')
		info.haste = 'DW: 22-36'
	elseif DW_needed > 36 then
		classes.CustomMeleeGroups:append('DW: 37+')
		info.haste = 'DW: 37+'
	end
	--add_to_chat(122,'Marches = '..tostring(state.Buff['Marches']) .. ' / geo = '..tostring(state.Buff['Geo-Haste']).. ' / haste = '..tostring(state.Buff['Haste']).. ' / haste2 = '..tostring(state.Buff['Haste II']))
	
	--add_to_chat(122, 'DW needed: '..DW_needed..' Haste: '..Total_haste..' / 1024  ....   Gearset: '..info.haste)
end

function determine_DW()
	-- sub job DW values
	-- nin = 25%
	-- dnc = 15%
	-- first we get the sub job trait values
	local sub_job_dw = 0
 	if player.sub_job:upper() == 'DNC' then sub_job_dw = 15
	elseif player.sub_job:upper() == 'NIN' then sub_job_dw = 25
	end
	
	-- here we look up job points spent on blue for the DW bonus
	local jp_boost = 0
	local jp = player.job_points['blu']['jp_spent']
	if jp < 100 then
		jp_boost = 0
	elseif jp >= 100 and jp < 1200 then
		jp_boost = 1
	elseif jp >= 1200 then
		jp_boost = 2
	end
	
	--here we look up spells currently equipped to check for DW trait
	local DW_Spells_Equipped_Level = 0
	local spells_set = T(windower.ffxi.get_mjob_data().spells):filter(function(id) return id ~= 512 end):map(function(id) return spells[id].english end)
	--table.vprint(spells_set)
	local spell_value = 0
	-- here we give each spell a value of 4 or 8 and add the values together
	for index, spell in pairs(spells_set) do
	--for spell in spells_set:it() do
        if spell == "Animating Wail" or spell == "Blazing Bound" or spell == "Quad. Continuum" or spell == "Delta Thrust" or spell == "Mortal Ray" or spell == "Barbed Crescent" then
           spell_value = spell_value + 4
		elseif spell == "Molting Plumage" then 
			spell_value = spell_value + 8
        end
		--add_to_chat(122, '[Spell: '.. spell .. '] [Spell value: ' .. spell_value.. ']')
    end
	--add_to_chat(122, '[Spell value: ' .. spell_value.. ']')
	
	--here we determine the DW level equipped with job points
	DW_Spells_Equipped_Level = math.floor(spell_value / 8) + jp_boost
	
	--the we determine the actuall % value of DW equipped via blu spells 
	local main_job_dw = 0
	if DW_Spells_Equipped_Level == 0 then main_job_dw = 0
	elseif DW_Spells_Equipped_Level == 1 then main_job_dw = 10
	elseif DW_Spells_Equipped_Level == 2 then main_job_dw = 15
	elseif DW_Spells_Equipped_Level == 3 then main_job_dw = 25
	elseif DW_Spells_Equipped_Level == 4 then main_job_dw = 30
	elseif DW_Spells_Equipped_Level == 5 then main_job_dw = 35
	elseif DW_Spells_Equipped_Level == 6 then main_job_dw = 40
	end
	--add_to_chat(122, '[Sub dw: ' .. sub_job_dw .. '] [Main dw: ' .. main_job_dw .. ']')
	
	-- if the sub job DW is higher return that instead of blue mage spell DW
	if sub_job_dw > main_job_dw then
		return sub_job_dw
	else
		return main_job_dw
	end
end

-- Select default macro book on initial load or subjob change.
function select_default_macro_book()
	
	-- send_command('bind ^` input /ja "Chain Affinity" <me>')
    -- send_command('bind !` input /ja "Occultation" <me>')
    -- send_command('bind @` input /ja "Burst Affinity" <me>')
	
	send_command('bind F8 input /ws "Chant Du Cygne" <t>')
	send_command('bind ^F8 input /ws "Requiescat" <t>')
	send_command('bind @F8 input /ws "Sanguine Blade" <t>')
	
	if player.sub_job:upper() == 'DNC' then
		send_command('bind !` input /ma "Occultation" <me>')
		send_command('bind ^` input /ma "Barrier Tusk" <me>')
		send_command('bind @` input /ma "Erratic Flutter" <me>')
		
		send_command('bind F7 input /ma "Sudden Lunge" <t>')
		send_command('bind @F7 input /ja "Box step" <stnpc>')
		send_command('bind ^F7 input /ja "Quick step" <stnpc>')
		
		send_command('bind F9 input /ja "Violent flourish" <stnpc>')
		send_command('bind ^F9 input /ja "Animated flourish" <stnpc>')
		send_command('bind @F9 input /ja "Haste Samba" <me>')
		
		send_command('bind @F10 input /ja "Divine Waltz" <me>')
		send_command('bind F10 input /ja "Healing Waltz" <me>')
		send_command('bind F11 input /ja "Curing Waltz III" <stal>')
		
		--send_command('bind ^` input /ja "Spectral jig" <me>')
	elseif player.sub_job:upper() == 'RDM' then		
		send_command('bind ^` input /ma "Occultation" <me>')
        send_command('bind !` input /ma "Stoneskin" <me>')
		send_command('bind @` input /ja "Aquaveil" <me>')
		
		send_command('bind F7 input /ma "Haste" <stal>')
		send_command('bind ^F7 input /ma "Refresh" <stal>')
		send_command('bind F9 input /ma "Phalanx" <me>')
		send_command('bind F10 input /ma "cure III" <stal>')
		send_command('bind F11 input /ma "cure IV" <stal>')
		
	elseif player.sub_job:upper() == 'WAR' then		
		send_command('bind !` input /ma "Occultation" <me>')
		send_command('bind ^` input /ma "Barrier Tusk" <me>')
		send_command('bind @` input /ma "Erratic Flutter" <me>')
		
		send_command('bind F7 input /ma "Sudden Lunge" <t>')
		send_command('bind F11 input /ma "Magic Fruit" <me>')
		send_command('bind F10 input /ma "Nat. Meditation" <me>')
		send_command('bind F9 input /ma "provoke" <stnpc>')
		send_command('bind ^F9 input /ra <stnpc>')
		
	elseif player.sub_job:upper() == 'NIN' then	
		send_command('bind ^` input /ma "utsusemi: ichi" <me>')
		send_command('bind !` input /ma "utsusemi: ni" <me>')
		
	elseif player.sub_job:upper() == 'RUN' then	
		send_command('bind !` input /ma "Occultation" <me>')
		send_command('bind ^` input /ma "Occultation" <me>')
		send_command('bind F9 input /ma "Flash" <stnpc>')
		
	end

    -- Default macro set/book
	set_macro_page(1, 20)
   
end

